var memberID =window.localStorage.getItem("memberNumber");
var role =window.localStorage.getItem("Role");
var commonURL=window.localStorage.getItem("URL");
var primaryKey = window.localStorage.getItem("primaryKey");

$(function(){	
	$("#div0").show();
	$("#div1").hide();
	$("#div6").hide();
});

function getCompanyList(){
	window.localStorage.setItem("Role","member");
	window.location.href = "dashboard.html";
}

function homePage(){
	$("#div0").show();
	$("#div1").hide();
	$("#div6").hide();
}

function selectPublic(){
	$("#div0").hide();
	$("#div1").show();
	$("#div6").hide();
}

function createPublicUnit(numberofUnit){
	var publicData = new Object();
	var publicData = JSON.stringify({
	   "numberofUnit" : numberofUnit,
	   "primaryKey" : primaryKey
	}); 
	var url = commonURL+"mobileTempPubliTreecUnitSave";
	$.ajax({
		url: url,
		cache: true,
		method: 'POST',
		data: publicData,
		dataType: "json",
		async: true,
		contentType: "application/json; charset=utf-8",
		beforeSend: function(){
			$("#div1").hide();
			$('.ajax-loader').css("visibility", "visible");
		},
		success: function(json) {
			$('.ajax-loader').css("visibility", "hidden");
			$("#div1").show();
			BootstrapDialog.alert('Thanks and Successfully purchase Public Unit');
			onClose(json);
		}, error: function (error) {
			$("#div1").show();
			$('.ajax-loader').css("visibility", "hidden");
			BootstrapDialog.alert('Network issue please try again');
		}
	});
	console.log("Called Successfully :::::::::::::::::::::::::::::");	
}

function onClose(json){
	$("#div0").hide();
	$("#div1").hide();
	$("#div6").show();
	console.log("Json Length -------"+json.length);
	for (var i = 0; i < json.length; i++) {
		ul = $('<ul class="w3-card-8">');
		ul.append('<li><h4 style="font-size: 20px;font-weight: bold;">  Unit Invoice Number #:' + json[i].invoiceNumber+ '</h4></li>');
		$("#publictreeview").append(ul);
		console.log("Json Amount -------"+json[0].totalAmount);
		$('#totalAmount').val(json[0].totalAmount);
	}
	
}
