var memberID =window.localStorage.getItem("memberNumber");
var role =window.localStorage.getItem("Role");
var commonURL=window.localStorage.getItem("URL");
var primaryKey = window.localStorage.getItem("primaryKey");

$(function(){	
	$("#div0").show();
	$("#div1").hide();
	$("#div6").hide();
	$('.ajax-loader').css("visibility", "hidden");
});

function getCompanyList(){
	window.localStorage.setItem("Role","member");
	window.location.href = "dashboard.html";
}

function homePage(){
	$("#div0").show();
	$("#div1").hide();
	$("#div6").hide();
	$('.ajax-loader').css("visibility", "hidden");
}

function selectPublic(){
	$("#div0").hide();
	$("#div1").show();
	$("#div6").hide();
	$('.ajax-loader').css("visibility", "hidden");
}

function createPublicUnit(numberofUnit){
	var publicData = new Object();
	var publicData = JSON.stringify({
	   "numberofUnit" : numberofUnit,
	   "primaryKey" : primaryKey
	}); 
	var url = commonURL+"mobileTempPubliTreecUnitSave";
	$.ajax({
		url: url,
		cache: true,
		method: 'POST',
		data: publicData,
		dataType: "json",
		async: true,
		contentType: "application/json; charset=utf-8",
		beforeSend: function(){
			$("#div1").hide();
			$('.ajax-loader').css("visibility", "visible");
		},
		success: function(json) {
			$('.ajax-loader').css("visibility", "hidden");
			$("#div1").show();
			BootstrapDialog.alert('Thanks and Successfully purchase Public Unit');
			onClose(json);
		}, error: function (error) {
			$("#div1").show();
			$('.ajax-loader').css("visibility", "hidden");
			BootstrapDialog.alert('Network issue please try again');
		}
	});
	console.log("Called Successfully :::::::::::::::::::::::::::::");	
}

function onClose(json){
	$("#div0").hide();
	$("#div1").hide();
	$("#div6").show();
	$('.ajax-loader').css("visibility", "hidden");
	ul = $('<ul class="w3-card-8">');
	ul.append('<li><label>   Thank you for buy the Unit from GGL Investment:</label></li>');
	for (var i = 0; i < json.length; i++) {
		ul.append('<li><h4 style="font-size: 17px;font-weight: bold;">  Unit Invoice Number #:' + json[i].invoiceNumber+ '</h4></li>');
	}
	ul.append('<li><div class="col-sm-4 col-xs-7"><label>  Amount Details :	</label> </div></li>');
	ul.append('<li><div class="col-sm-4 col-xs-2"><output id="totalAmount" style="font-weight: bold;"></output></div></li>');
	ul.append('<li><div class="col-sm-4 col-xs-3"><label>  SGD </label></div></li>');
	ul.append('<li><br/></li>');
	ul.append('<li>Note</li>');
	ul.append('<li>Please make the payment via Wire transfer or Online payment </li>');
	ul.append('<li><br/></li>');
	ul.append('<li><br/></li>');
	ul.append('<li>For and on behalf of</li>');
	ul.append('<li>Global Gains Limited </li>');
	$("#publictreeview").append(ul);
	$('#totalAmount').val(json[0].totalAmount);

}
