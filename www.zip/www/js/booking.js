var commonURL=window.localStorage.getItem("URL");
var Role=window.localStorage.getItem("Role");
var primaryKey = window.localStorage.getItem("primaryKey");

$(function(){		
	var url=commonURL+"getHotelNameList";
	$.ajax({
		dataType: "json",
		url: url,
		method: 'GET',
		success: function(json) {
			for (var i = 0; i < json.length; i++) {
				select = $('<option>');
				select.append("<option>" + json[i]+ "<option>");
				$('#companyname').append(select);
			}
		}
	}); 
});

function saveReservation(){
	var selectedCountry = "Indonesia";
	var selectedState = "Bangka Belitung";
	var categoryname = "Food and hotels";
	var companyname=$('#companyname').val();
	var noofadult=$('#noofadult').val();
	var noofchild=$('#noofchild').val();
	var noofrooms=$('#noofrooms').val();
	var bookingdate=$('#bookingdate').val();
	var medicaltime=$('#medicaltime').val();
	var noofTables=$('#noofTables').val();
	
	var myData = new Object();
	var myData = JSON.stringify({
		"primaryKey" : primaryKey,
		"selectedCountry" : selectedCountry,
		"selectedState" : selectedState,
		"categoryname" : categoryname,
		"companyname" : companyname,
		"noofadult" : noofadult,
		"noofchild" : noofchild,
		"noofrooms" : noofrooms,
		"bookingdate" : bookingdate,
		"medicaltime" : medicaltime,
		"noofTables": noofTables
	});
	var url = commonURL+"saveHotelBooking";
	$.ajax({
		url: url,
		cache: true,
		method: 'POST',
		data: myData,
		dataType: "json",
		async: true,
		contentType: "application/json; charset=utf-8",
		beforeSend: function(){
			console.log("Before Called Function Successfully :::::::::::");
			$('.ajax-loader').css("visibility", "hidden");
		},
		success: function(json) {
			$('.ajax-loader').css("visibility", "hidden");
			alert("Status -----"+json);
			if(json=="success"){
				$('.panel-body').find("input[type=text],input[type=number],input[type=date],input[type=password], select ").val("");
				alert("Successfully Saved Data.");
				BootstrapDialog.alert('Successfully Saved Data.');
			}else if(json=="failure"){
				alert("Successfully not Saved Data.");
				BootstrapDialog.alert('Successfully not Saved Data.');
			}else{
				alert("Due to some Technical issue. Please try later.");
				BootstrapDialog.alert('Due to some Technical issue. Please try later.');
			}
		},
		complete: function(){
			$('.ajax-loader').css("visibility", "hidden");
		}
	});
	console.log("Called Successfully :::::::::::::::::::::::::::::");	
}

function getCompanyList(){
	window.localStorage.setItem("Role","member");
	window.location.href = "dashboard.html";
}

function logoff() {
	window.location.href = "index.html";
} 