var memberID =window.localStorage.getItem("memberNumber");
var role =window.localStorage.getItem("Role");
var commonURL=window.localStorage.getItem("URL");
var primaryKey = window.localStorage.getItem("primaryKey");

$(function(){	
	$("#payUpload").show();
});

function home(){
	window.location.href = "dashboard.html";
}

function imageupload(){
    var filesSelected = document.getElementById("upload").files;
    if (filesSelected.length > 0){
        var fileToLoad = filesSelected[0];
        var fileReader = new FileReader();
        fileReader.onload = function(fileLoadedEvent) {
            var srcData = fileLoadedEvent.target.result; 
			var invoiceNumber=document.getElementById("invoiceNumber").value;
			var treeName=document.getElementById("treeName").value;
			var treeimage = new Object();
			var treeimage=JSON.stringify({
				"srcData":srcData,
				"invoiceNumber":invoiceNumber,
				"treeName":treeName
			});
			var url = commonURL+"uploadimage";
			$.ajax({
				url: url,
				cache: true,
				method: 'POST',
				data:treeimage,
				dataType: "json",
				async: true,
				contentType: "application/json; charset=utf-8",
				success: function(json) {
					if(json.status=="success"){
						$('#hidden').val(json);
						BootstrapDialog.alert("Image was Uploaded successfully");
					}else if(profileupdatestatus=="failure"){
						BootstrapDialog.alert("Profile Information was not updated ....");
					}
				}
			});
			/* var xmlHttp = createXHRObject();			
			xmlHttp.open("POST", url, false);
			xmlHttp.setRequestHeader("Content-type", "application/json");
			xmlHttp.onreadystatechange = function() {
				if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
					var json = JSON.parse(xmlHttp.responseText);
					$('#hidden').val(json);
				}
			}
			xmlHttp.send(treeimage); */
		}
	fileReader.readAsDataURL(fileToLoad);
	}
}

function getCompanyList(){
	window.localStorage.setItem("Role","member");
	window.location.href = "dashboard.html";
}